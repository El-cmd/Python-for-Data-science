# ft_package

Un exemple de package Python simple pour la piscine Data Science.
