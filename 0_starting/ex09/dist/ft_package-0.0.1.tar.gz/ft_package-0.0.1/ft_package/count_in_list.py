def count_in_list(lst, element):
    return lst.count(element)