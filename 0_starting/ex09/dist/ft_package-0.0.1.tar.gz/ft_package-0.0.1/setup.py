from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    packages=find_packages(),
    license="MIT",
    url="https://github.com/El-cmd/Python-for-Data-science",
    author="vloth",
    author_email="vloth@student.42.fr",
    description="A simple package for testing",   
)
